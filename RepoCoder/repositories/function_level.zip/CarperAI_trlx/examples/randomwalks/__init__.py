from .randomwalks import generate_random_walks
