rm -rf _build
make html
firefox ../../betty-docs/html/index.html
open -a Safari ../../betty-docs/html/index.html
