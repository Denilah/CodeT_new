# Omniglot
python main.py --task mini-imagenet --ways 5 --shots 1 --reg 0.01
python main.py --task mini-imagenet --ways 5 --shots 5 --reg 0.01
