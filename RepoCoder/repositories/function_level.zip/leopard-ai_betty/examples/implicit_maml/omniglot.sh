# Omniglot
python main.py --ways 5 --shots 1 --reg 0.01
python main.py --ways 5 --shots 5 --reg 0.01
python main.py --ways 20 --shots 1 --reg 0.003
python main.py --ways 20 --shots 5 --reg 0.003
